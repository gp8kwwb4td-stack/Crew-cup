# Critter Cup ⚽

A 3-a-side 3D football game starring 15 wild characters: sharks, a fox, dinosaurs, an orca, a giraffe, a parrot, a gorilla and more.

## Play

Open `index.html` in any modern browser. It's a single self-contained file with no build step and no install. If GitHub Pages is turned on for this repo, the game is playable at the Pages link.

## Features

- **Pick your squad:** choose 3 of 15 characters (striker, midfielder, keeper) and face 3 random rivals.
- **3D stadium:** a perspective camera, a floodlit night stadium, a cheering crowd and goals with nets.
  - **Phone (upright):** the camera sits behind your goal.
  - **Landscape or desktop:** TV-style side camera.
- **Real dribbling:** every step pushes the ball ahead. Turn sharply, keep it close, or lose it to a defender.
- **Skill moves:** roulette, step-over, elastico and rainbow flick. Fooled defenders go dizzy.
- **Gameplay:** lofted shots with power charge, smart passing, sliding tackles, keeper saves.
- **Settings:** Easy, Normal or Hard difficulty, and 1, 2 or 3 minute matches.

## Controls

| Action | Touch | Keyboard |
|---|---|---|
| Move | Drag on the left side | WASD / Arrows |
| Shoot (hold for power) / Tackle | SHOOT | Space |
| Pass / Switch player | PASS | K |
| Skill move | SKILL | L |
| Pause | ❚❚ | Esc / P |
